struct Tracking: Codable {
    let idTracking: Int
    let trackingNumber: String // Este es el que vamos a mostrar
    let idBatch: Int?
    let dateTracking: String
    let idStatus: Int
    let urgent: Bool
    let discrepant: Bool
    let damaged: Bool
    let idObjectType: Int
    let idCarrier: Int
    let partial: Int
    let idLocationType: Int
    let originalTrackingNumber: String?
    let idParcel: Int?
    
    enum CodingKeys: String, CodingKey {
        case idTracking = "ID_TRACKING"
        case trackingNumber = "TRACKING_NUMBER" // Clave para el número de tracking
        case idBatch = "ID_BATCH"
        case dateTracking = "DATE_TRACKING"
        case idStatus = "ID_STATUS"
        case urgent = "URGENT"
        case discrepant = "DISCREPANT"
        case damaged = "DAMAGED"
        case idObjectType = "ID_OBJECT_TYPE"
        case idCarrier = "ID_CARRIER"
        case partial = "PARTIAL"
        case idLocationType = "ID_LOCATION_TYPE"
        case originalTrackingNumber = "ORIGINAL_TRACKING_NUMBER"
        case idParcel = "ID_PARCEL"
    }
}
