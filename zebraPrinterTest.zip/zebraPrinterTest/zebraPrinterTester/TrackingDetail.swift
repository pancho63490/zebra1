//
//  TrackingDetail.swift
//  zebraPrinterTester
//
//  Created by Frank Perez on 18/09/24.
//

import Foundation
