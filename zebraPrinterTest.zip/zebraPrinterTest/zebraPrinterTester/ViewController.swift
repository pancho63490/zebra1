import UIKit
import CoreBluetooth
import ExternalAccessory

class ViewController: UIViewController, CBCentralManagerDelegate {

    @IBOutlet weak var printerListTable: UITableView!
    
    var centralManager: CBCentralManager!
    var connectedAccessories: [EAAccessory] = []
    
    // Propiedad para almacenar el código escaneado recibido desde OrderDetailViewController
    var scannedCode: String?
    var idObjectToPrint: Int?
    var onPrintCompletion: (() -> Void)?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Inicializar CBCentralManager para manejar el estado de Bluetooth
        print("viewDidLoad: Vista cargada, comenzando a inicializar CBCentralManager.")
        centralManager = CBCentralManager(delegate: self, queue: nil)
        updateConnectedAccessories()
    }
    
    // MARK: - CBCentralManagerDelegate
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn:
            print("centralManagerDidUpdateState: Bluetooth está encendido.")
            self.updateConnectedAccessories() // Actualizar accesorios conectados si Bluetooth está encendido
        case .poweredOff:
            print("centralManagerDidUpdateState: Bluetooth está apagado. Pide al usuario que lo active.")
        case .resetting:
            print("centralManagerDidUpdateState: Bluetooth se está reiniciando.")
        case .unauthorized:
            print("centralManagerDidUpdateState: La app no tiene permisos para usar Bluetooth.")
        case .unsupported:
            print("centralManagerDidUpdateState: El dispositivo no soporta Bluetooth.")
        case .unknown:
            print("centralManagerDidUpdateState: Estado desconocido de Bluetooth.")
        @unknown default:
            print("centralManagerDidUpdateState: Estado no manejado.")
        }
    }
    
    @IBAction func refreshBtnTouchUp(_ sender: Any) {
        print("refreshBtnTouchUp: Botón de refresco presionado.")
        updateConnectedAccessories()
        printerListTable.reloadData()
    }
    
    // Actualizar accesorios conectados
    private func updateConnectedAccessories() {
        connectedAccessories = EAAccessoryManager.shared().connectedAccessories
        if connectedAccessories.isEmpty {
            print("updateConnectedAccessories: No se encontraron impresoras conectadas.")
        } else {
            for accessory in connectedAccessories {
                print("Accesorio encontrado: \(accessory.name) \(accessory.modelNumber) \(accessory.serialNumber)")
            }
        }
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return connectedAccessories.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "Cell"
        var cell: UITableViewCell!
        cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: cellIdentifier)
        }
        
        let eaAccessory = connectedAccessories[indexPath.row]
        cell.textLabel?.text = "\(eaAccessory.name) \(eaAccessory.modelNumber) \(eaAccessory.serialNumber)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("didSelectRowAt: Impresora seleccionada en el índice \(indexPath.row).")
        self.connectEaAccessory(eaAccessory: connectedAccessories[indexPath.row])
    }
}

extension ViewController {

    //// Método para conectar con la impresora
    private func connectEaAccessory(eaAccessory: EAAccessory) {
        print("connectEaAccessory: Intentando conectar con la impresora \(eaAccessory.name) \(eaAccessory.modelNumber).")
        
        if eaAccessory.modelNumber.hasPrefix("ZQ630") {
            print("connectEaAccessory: Es una impresora Zebra ZQ630. Intentando conexión...")
            
            // Zebra SDK requires communication in background thread
            DispatchQueue.global(qos: .background).async {
                guard let connection = MfiBtPrinterConnection(serialNumber: eaAccessory.serialNumber) else {
                    print("connectEaAccessory: Error al inicializar la conexión Bluetooth.")
                    return
                }
                
                if connection.open() {
                    print("connectEaAccessory: Conexión exitosa con la impresora \(eaAccessory.name).")
                    do {
                        var printer: ZebraPrinter & NSObjectProtocol
                        printer = try ZebraPrinterFactory.getInstance(connection)
                        
                        let printerLanguage = printer.getControlLanguage()
                        print("La impresora usa el siguiente lenguaje: \(printerLanguage)")
                        
                        if printerLanguage == PRINTER_LANGUAGE_ZPL {
                            print("Conectado con ZPL. Configurando y enviando comandos.")
                            self.configureLabelSize(connection: connection)
                            self.printScannedAndObject(connection: connection)  // Imprimir el código escaneado y el ID_OBJECT
                            DispatchQueue.main.async {
                                self.showPrintSuccessAlert()  // Mostrar alerta después de imprimir
                                self.onPrintCompletion?()     // Asegúrate de que la impresión se marca como completada
                            }
                        } else {
                            print("Conectado, pero la impresora no usa ZPL.")
                        }
                        
                    } catch {
                        print("Error al obtener la instancia de la impresora: \(error.localizedDescription)")
                    }
                } else {
                    print("Error al abrir la conexión con la impresora \(eaAccessory.name).")
                }
            }
        } else {
            print("connectEaAccessory: El accesorio seleccionado no es una impresora ZQ630.")
        }
    }

    // Mostrar alerta después de la impresión exitosa
    private func showPrintSuccessAlert() {
        let alert = UIAlertController(title: "Impresión Exitosa", message: "El código ha sido impreso correctamente.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            self.navigationController?.popViewController(animated: true)  // Retornar a la vista de detalles
        }))
        self.present(alert, animated: true, completion: nil)
    }

    // Enviar comandos de configuración a la impresora
    private func configureLabelSize(connection: ZebraPrinterConnection) {
        let strToSend = """
        ^XA
        ^PW609      // Ancho de la etiqueta de 4 pulgadas (812 puntos)
        ^LL609     // Largo de la etiqueta de 3 pulgadas (609 puntos)
        ^PR5       // Velocidad de impresión media
        ^MTT       // Método de impresión térmica directa
        ^MMT       // Modo de manejo del material: Tear-off (desprender etiquetas)
        ^XZ
        """
        sendStrToPrinter(strToSend, connection: connection)
    }
    
    // Método para imprimir el código escaneado y el ID_OBJECT
    private func printScannedAndObject(connection: ZebraPrinterConnection) {
        if let code = scannedCode, let objectId = idObjectToPrint, !code.isEmpty {
            let zplCommand = """
            ^XA~TA000~JSN^LT0^MNW^MTT^PON^PMN^LH0,0^JMA^PR6,6~SD15^JUS^LRN^CI0^XZ
            ^XA
            ^MMT
            ^FT127,52^A0N,45,45^FH\\^FDB O S C H  -  X  D O C K^FS
            ^FO1,63^GB811,0,4^FS
            ^FO0,10^GB0,608,5^FS
            ^FO810,8^GB0,608,5^FS
            ^FO385,66^GB0,600,5^FS
            ^BY2,3,70^FT201,200^BCR,,Y,N
            ^FD>:\(objectId)^FS
            ^FT644,84^A0R,28,28^FH\\^FDArrival Date^FS
            ^FT571,197^A0R,45,45^FH\\^FD\(getCurrentDateTime())^FS
            ^BY2,3,70^FT530,763^BCR,,Y,N
            ^FD>:\(code)^FS
            ^PQ0,0,1,Y^XZ
            """
            print("Imprimiendo código escaneado: \(code) y ID Object: \(objectId)")
            sendStrToPrinter(zplCommand, connection: connection)
        } else {
            print("No hay código escaneado o ID_OBJECT, enviando impresión de prueba.")
            let testingStr = "^XA^FO50,50^ADN,36,20^FDTEST^FS^XZ"
            sendStrToPrinter(testingStr, connection: connection)
        }
    }

    // Método para enviar los comandos a la impresora
    private func sendStrToPrinter(_ strToSend: String, connection: ZebraPrinterConnection) {
        let data = strToSend.data(using: .utf8)!
        var error: NSErrorPointer = nil
        connection.write(data, error: error)
        if let err = error {
            print("Error al enviar los datos a la impresora: \(err.debugDescription)")
        } else {
            print("Datos enviados exitosamente a la impresora.")
        }
    }
    
    // Método para obtener la fecha y hora actual
    private func getCurrentDateTime() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return dateFormatter.string(from: Date())
    }
}
