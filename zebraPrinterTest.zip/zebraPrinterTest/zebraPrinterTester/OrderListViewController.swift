import UIKit

class OrderListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var logoImageView: UIImageView!
   
    @IBOutlet weak var LogoB: UIImageView!
    let viewModel = TrackingViewModel() // Instancia del ViewModel
    var trackings: [Tracking] = []

          
  
    override func viewDidLoad() {
        super.viewDidLoad()
      
        // Asignar la imagen del logo
        logoImageView.image = UIImage(named: "Boschbaner") // Asegúrate de que "Boschbaner" esté en tu Assets
             LogoB.image = UIImage(named: "logo1") // Asegúrate de que "Logo" esté en tu Assets
             
             // Desactivar las restricciones automáticas
             logoImageView.translatesAutoresizingMaskIntoConstraints = false
             LogoB.translatesAutoresizingMaskIntoConstraints = false
             
             // Agregar los UIImageView a la vista principal
             view.addSubview(logoImageView)
             view.addSubview(LogoB)
             
             // Configurar el modo de contenido para llenar todo el espacio
             logoImageView.contentMode = .scaleToFill // Cambia a .scaleAspectFit o .scaleAspectFill si prefieres
             LogoB.contentMode = .scaleAspectFit// Puedes cambiar según el comportamiento que prefieras
             
             // Agregar restricciones para logoImageView
             NSLayoutConstraint.activate([
                 // logoImageView - Posicionar en el centro horizontal y en la parte superior
              // Ajusta según el tamaño deseado
                 logoImageView.heightAnchor.constraint(equalToConstant: 20)  ,// Ajusta según el tamaño deseado
            
             
             // Agregar restricciones para LogoB
     
                 LogoB.heightAnchor.constraint(equalToConstant: 70)  // Ajusta según el tamaño deseado
             ])
              
              
        tableView.dataSource = self
        tableView.delegate = self

        // Llama a la API para obtener los datos
        viewModel.fetchTrackings { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let trackings):
                    self?.trackings = trackings
                    self?.tableView.reloadData() // Refresca la tabla con los nuevos datos
                case .failure(let error):
                    print("Error al obtener los datos: \(error)")
                }
            }
        }
    }

    // MARK: - UITableViewDataSource

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return trackings.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OrderCell", for: indexPath)

        let tracking = trackings[indexPath.row]
        // Mostrar el TRACKING_NUMBER en la celda
        cell.textLabel?.text = "Tracking Number: \(tracking.trackingNumber)" // Mostrar TRACKING_NUMBER

        return cell
    }

    // MARK: - UITableViewDelegate

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedTracking = trackings[indexPath.row]
        print("Tracking seleccionado: \(selectedTracking.trackingNumber)")
        
        // Instanciar el controlador de detalles desde el Storyboard
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let orderDetailVC = storyboard.instantiateViewController(withIdentifier: "OrderDetailViewController") as? OrderDetailViewController {
            
            // Pasar el `idTracking` seleccionado al controlador de detalles
            orderDetailVC.orderId = "\(selectedTracking.idTracking)" // Convertimos el idTracking a String
            orderDetailVC.trakingnumber = "\(selectedTracking.trackingNumber)"
            // Navegar al controlador de detalles
            self.navigationController?.pushViewController(orderDetailVC, animated: true)
        }
    }
}
