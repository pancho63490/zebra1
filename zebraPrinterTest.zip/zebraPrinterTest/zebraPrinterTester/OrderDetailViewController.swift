import AVFoundation
import UIKit

class OrderDetailViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate, UITableViewDelegate, UITableViewDataSource {

    // UI Elements
    @IBOutlet weak var ScanCode: UIButton!
    @IBOutlet weak var orderIdLabel: UILabel!          // Muestra el ID de la orden
    @IBOutlet weak var scannedCodeLabel: UILabel!      // Muestra el código escaneado
    @IBOutlet weak var boxesQtyLabel: UILabel!         // Muestra la cantidad de cajas restantes
    @IBOutlet weak var printerButton: UIButton!        // Botón para seleccionar impresora
    @IBOutlet weak var printButton: UIButton!          // Botón para imprimir
    @IBOutlet weak var imagenlogo: UIImageView!
    @IBOutlet weak var Imagenbaner: UIImageView!
    @IBOutlet weak var tableView: UITableView!         // TableView para mostrar los ID_OBJECT y ID_LOCATION
    
    var orderId: String = ""  // Recibido desde la pantalla anterior
    var scannedCode: String?
    var verificationCode: String?  // Código de verificación
    var idObjects: [TrackingDetail] = [] // Almacena los objetos obtenidos
    var currentObjectIndex: Int = 0  // Para controlar qué ID_OBJECT estamos imprimiendo
    var trakingnumber: String = ""
    var remainingBoxes: Int = 0 // Cantidad de cajas restantes

    override func viewDidLoad() {
        super.viewDidLoad()

        print("viewDidLoad: Vista cargada, inicializando componentes.")
        
        // Ocultar la tabla al inicio
        tableView.isHidden = true
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "TrackingCell")
        // Asignar las imágenes
        imagenlogo.image = UIImage(named: "logo1")
        Imagenbaner.image = UIImage(named: "Boschbaner")
        imagenlogo.translatesAutoresizingMaskIntoConstraints = false
        Imagenbaner.translatesAutoresizingMaskIntoConstraints = false
        imagenlogo.contentMode = .scaleAspectFit
        Imagenbaner.contentMode = .scaleToFill
        
        // Configurar las restricciones
        NSLayoutConstraint.activate([
            imagenlogo.heightAnchor.constraint(equalToConstant: 70),
            Imagenbaner.heightAnchor.constraint(equalToConstant: 20)
        ])
        
        orderIdLabel.text = "La Orden es: " + trakingnumber

        // Configurar la tabla
        tableView.delegate = self
        tableView.dataSource = self

        // Obtener los detalles de tracking
        fetchTrackingDetails(orderId: orderId)
        
        // Mostrar la cantidad inicial de cajas
        updateBoxesQtyLabel()
    }

    @IBAction func ScanCode(_ sender: UIButton) {
        // Si aún hay cajas restantes, iniciar el proceso de escaneo
        if remainingBoxes > 0 {
            print("ScanCode: Hay \(remainingBoxes) cajas restantes, iniciando escaneo.")
            initiateScanProcess()  // Iniciar el primer escaneo
        } else {
            print("ScanCode: Todas las cajas han sido procesadas.")
            showFinalTableView()  // Mostrar la tabla cuando todas las cajas se hayan procesado
        }
    }

    // Proceso de escaneo inicial
    func initiateScanProcess() {
        if presentedViewController == nil {
            print("initiateScanProcess: Presentando escáner de código.")
            let scannerVC = BarcodeScannerViewController()
            scannerVC.completion = { [weak self] scannedValue in
                guard let self = self else { return }
                self.scannedCode = scannedValue
                print("initiateScanProcess: Código escaneado: \(self.scannedCode ?? "Ninguno")")
                DispatchQueue.main.async {
                    self.dismiss(animated: true) {
                        self.promptForVerificationScan()  // Mostrar el escáner de verificación
                    }
                }
            }
            present(scannerVC, animated: true, completion: nil)
        }
    }

    // Escaneo de verificación
    func promptForVerificationScan() {
        if presentedViewController == nil {
            print("promptForVerificationScan: Presentando escáner de verificación.")
            let verificationScannerVC = BarcodeScannerViewController()
            verificationScannerVC.completion = { [weak self] verificationValue in
                guard let self = self else { return }
                self.verificationCode = verificationValue
                print("promptForVerificationScan: Código de verificación escaneado: \(self.verificationCode ?? "Ninguno")")
                DispatchQueue.main.async {
                    self.dismiss(animated: true) {
                        self.launchPrintProcess()  // Continuar con el flujo después del escaneo de verificación
                    }
                }
            }
            present(verificationScannerVC, animated: true, completion: nil)
        }
    }

    // Lanzar el proceso de impresión y la vista de selección de impresora
    func launchPrintProcess() {
        // Ejecutar la API antes de la impresión
        let idObject = idObjects[currentObjectIndex].idObject
        let idLocation = 1
        executeApiCall(idObject: idObject, idLocation: idLocation)

        print("launchPrintProcess: Preparando impresión para código \(scannedCode ?? "Ninguno") e ID Object: \(idObject)")

        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let printerVC = storyboard.instantiateViewController(withIdentifier: "ViewController") as? ViewController {
            printerVC.scannedCode = self.scannedCode  // Pasar el código escaneado al ViewController de la impresora
            printerVC.idObjectToPrint = idObjects[currentObjectIndex].idObject  // Pasar el ID_OBJECT actual para imprimir
            printerVC.onPrintCompletion = { [weak self] in
                self?.handlePrintCompletion()  // Llamar cuando termine de imprimir
            }
            navigationController?.pushViewController(printerVC, animated: true)
        }
    }

    // Ejecutar la API antes de la impresión (con id_object e id_location)
    func executeApiCall(idObject: Int, idLocation: Int) {
        print("Ejecutando llamada a la API con ID Object: \(idObject), ID Location: \(idLocation)")
        
        let urlString = "https://ews-emea.api.bosch.com/Api_XDock/api/tracking/updateLocation"
        guard let url = URL(string: urlString) else {
            print("URL inválida para la API.")
            return
        }

        // Crear el cuerpo de la solicitud
        let parameters: [String: Any] = [
            "id_object": idObject,
            "id_location": idLocation
        ]
        
        guard let httpBody = try? JSONSerialization.data(withJSONObject: parameters, options: []) else {
            print("Error al serializar los parámetros.")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = httpBody

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print("Error al hacer la solicitud de la API: \(error?.localizedDescription ?? "Error desconocido")")
                return
            }

            // Procesar la respuesta si es necesario
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                print("La API devolvió una respuesta exitosa: \(httpResponse.statusCode)")
            } else {
                print("Error en la respuesta de la API.")
            }

            do {
                // Procesar los datos recibidos
                let responseJSON = try JSONSerialization.jsonObject(with: data, options: [])
                print("Respuesta de la API: \(responseJSON)")
            } catch {
                print("Error al decodificar la respuesta de la API: \(error.localizedDescription)")
            }
        }

        task.resume()
    }

    // Manejar la finalización de la impresión
    func handlePrintCompletion() {
        print("handlePrintCompletion: Impresión completada.")
        
        // Reducir la cantidad de cajas restantes
        remainingBoxes -= 1
        print("Cajas restantes: \(remainingBoxes)")
        
        // Actualizar la etiqueta del contador de cajas
        updateBoxesQtyLabel()

        // Verificar si no quedan más cajas
        if remainingBoxes == 0 {
            print("handlePrintCompletion: Todas las cajas procesadas, deshabilitando botón de escaneo.")
            disableScanButton()
            showFinalTableView()  // Mostrar la tabla cuando se terminen todas las cajas
        } else {
            print("handlePrintCompletion: Aún quedan cajas por procesar.")
        }
    }

    // Actualizar la etiqueta con la cantidad de cajas restantes
    func updateBoxesQtyLabel() {
        DispatchQueue.main.async {
            self.boxesQtyLabel.text = "Cajas restantes: \(self.remainingBoxes)"
            print("Etiqueta de cajas actualizada a \(self.remainingBoxes)")
        }
    }

    // Deshabilitar el botón de escaneo cuando se terminen las cajas
    func disableScanButton() {
        DispatchQueue.main.async {
            self.ScanCode.isEnabled = false
            self.ScanCode.alpha = 0.5  // Cambiar la apariencia para indicar que está deshabilitado
        }
    }

    // Mostrar la tabla con los detalles al finalizar
    func showFinalTableView() {
        DispatchQueue.main.async {
            print("showFinalTableView: Mostrando tabla de detalles.")
            self.tableView.isHidden = false
            self.tableView.reloadData()
        }
    }

    // Función para hacer la llamada a la API y cargar los objetos
    func fetchTrackingDetails(orderId: String) {
        let urlString = "https://ews-emea.api.bosch.com/Api_XDock/api/tracking/details/\(orderId)"
        guard let url = URL(string: urlString) else {
            print("fetchTrackingDetails: URL inválida.")
            return
        }

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                print("fetchTrackingDetails: Error al obtener los datos: \(error?.localizedDescription ?? "Desconocido").")
                return
            }

            do {
                let trackingDetails = try JSONDecoder().decode([TrackingDetail].self, from: data)
                self.idObjects = trackingDetails
                self.remainingBoxes = trackingDetails.count  // Inicializar la cantidad de cajas
                print("fetchTrackingDetails: Detalles de tracking obtenidos. Cajas iniciales: \(self.remainingBoxes).")
                DispatchQueue.main.async {
                    self.updateBoxesQtyLabel()  // Mostrar la cantidad de cajas al iniciar
                }
            } catch {
                print("fetchTrackingDetails: Error al decodificar los datos: \(error.localizedDescription).")
            }
        }

        task.resume()
    }

    // MARK: - Métodos de UITableView

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return idObjects.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TrackingCell", for: indexPath)
        let trackingDetail = idObjects[indexPath.row]
        cell.textLabel?.text = "ID_OBJECT: \(trackingDetail.idObject), ID_LOCATION: \(trackingDetail.idLocation)"
        return cell
    }
}

// Estructura de datos para el TrackingDetail
struct TrackingDetail: Decodable {
    let idLocation: Int
    let idObject: Int
    let idStatus: Int
    let idTracking: Int

    enum CodingKeys: String, CodingKey {
        case idLocation = "ID_LOCATION"
        case idObject = "ID_OBJECT"
        case idStatus = "ID_STATUS"
        case idTracking = "ID_TRACKING"
    }
}
