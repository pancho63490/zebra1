import Foundation

class TrackingViewModel {
    
    func fetchTrackings(completion: @escaping (Result<[Tracking], Error>) -> Void) {
        let urlString = "https://ews-emea.api.bosch.com/Api_XDock/api/tracking"
        guard let url = URL(string: urlString) else {
            completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "URL inválida"])))
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "No se recibieron datos"])))
                return
            }
            
            do {
                // Decodifica el JSON en lugar de intentar parsear XML
                let trackings = try JSONDecoder().decode([Tracking].self, from: data)
                completion(.success(trackings))
            } catch {
                completion(.failure(error))
            }
        }
        task.resume()
    }
}
